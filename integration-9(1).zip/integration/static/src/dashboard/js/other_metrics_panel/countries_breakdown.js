/** @odoo-module **/

import { Component } from '@odoo/owl';

export class CountriesBreakdownCard extends Component { }

CountriesBreakdownCard.props = ['data'];
CountriesBreakdownCard.template = 'integration.CountriesBreakdownCardTemplate';
