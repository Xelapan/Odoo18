/** @odoo-module **/

import { Component } from '@odoo/owl';

export class StorePerformanceBreakdownCard extends Component { }

StorePerformanceBreakdownCard.props = ['data'];
StorePerformanceBreakdownCard.template = 'integration.StorePerformanceBreakdownCardTemplate';
